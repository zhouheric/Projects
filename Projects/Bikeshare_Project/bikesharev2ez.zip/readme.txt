References to the bikeshare project:
https://pandas.pydata.org/pandas-docs/stable/generated/pandas.DataFrame.groupby.html
http://pandas.pydata.org/pandas-docs/version/0.22/generated/pandas.Series.value_counts.html
https://stackoverflow.com/questions/17322208/multiple-try-codes-in-one-block
Udacity videos in the Intro to Python course/ part of the data analyst nanodegree
